-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.3.14-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for recipe_drawer
CREATE DATABASE IF NOT EXISTS `recipe_drawer` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `recipe_drawer`;

-- Dumping structure for table recipe_drawer.categories
CREATE TABLE IF NOT EXISTS `categories` (
  `categoryID` int(11) NOT NULL AUTO_INCREMENT,
  `categoryname` varchar(50) NOT NULL,
  PRIMARY KEY (`categoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table recipe_drawer.comment
CREATE TABLE IF NOT EXISTS `comment` (
  `commentID` int(11) NOT NULL AUTO_INCREMENT,
  `commentuser` varchar(50) NOT NULL,
  `commenttext` varchar(255) DEFAULT NULL,
  `commenttime` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`commentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table recipe_drawer.comment_reply
CREATE TABLE IF NOT EXISTS `comment_reply` (
  `commentID` int(11) NOT NULL AUTO_INCREMENT,
  `commentparent` int(11) NOT NULL DEFAULT 0,
  `commentuser` varchar(50) NOT NULL,
  `commenttext` varchar(255) DEFAULT NULL,
  `commenttime` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`commentID`),
  KEY `comment_reply_fk_1` (`commentparent`),
  CONSTRAINT `comment_reply_fk_1` FOREIGN KEY (`commentparent`) REFERENCES `comment` (`commentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table recipe_drawer.comment_report
CREATE TABLE IF NOT EXISTS `comment_report` (
  `commentID` int(11) NOT NULL,
  `reporterID` int(11) NOT NULL,
  `reportreason` varchar(255) DEFAULT NULL,
  `reportedtime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table recipe_drawer.flags
CREATE TABLE IF NOT EXISTS `flags` (
  `flagID` int(11) NOT NULL AUTO_INCREMENT,
  `flagname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`flagID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table recipe_drawer.flag_recipe
CREATE TABLE IF NOT EXISTS `flag_recipe` (
  `flagID` int(11) NOT NULL,
  `recipeID` int(11) NOT NULL,
  PRIMARY KEY (`flagID`,`recipeID`),
  KEY `flag_assign_fk_2` (`recipeID`),
  CONSTRAINT `flag_assign_fk_1` FOREIGN KEY (`flagID`) REFERENCES `flags` (`flagID`),
  CONSTRAINT `flag_assign_fk_2` FOREIGN KEY (`recipeID`) REFERENCES `recipe` (`recipeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table recipe_drawer.login
CREATE TABLE IF NOT EXISTS `login` (
  `UserID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Role` int(10) unsigned zerofill NOT NULL,
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `ID` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table recipe_drawer.recipe
CREATE TABLE IF NOT EXISTS `recipe` (
  `recipeID` int(11) NOT NULL AUTO_INCREMENT,
  `recipeuser` varchar(50) NOT NULL,
  `recipename` varchar(50) DEFAULT NULL,
  `recipeinstruction` varchar(5000) DEFAULT NULL,
  `recipedirection` varchar(5000) DEFAULT NULL,
  `recipepicture` mediumblob DEFAULT NULL,
  PRIMARY KEY (`recipeID`),
  UNIQUE KEY `recipeID` (`recipeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table recipe_drawer.recipe_category
CREATE TABLE IF NOT EXISTS `recipe_category` (
  `categoryID` int(11) NOT NULL,
  `recipeID` int(11) NOT NULL,
  PRIMARY KEY (`categoryID`,`recipeID`),
  KEY `recipe_category_fk_2` (`recipeID`),
  CONSTRAINT `recipe_category_fk_1` FOREIGN KEY (`categoryID`) REFERENCES `categories` (`categoryID`),
  CONSTRAINT `recipe_category_fk_2` FOREIGN KEY (`recipeID`) REFERENCES `recipe` (`recipeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table recipe_drawer.users
CREATE TABLE IF NOT EXISTS `users` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `bio` varchar(255) DEFAULT NULL,
  `picture` mediumblob DEFAULT NULL,
  PRIMARY KEY (`userid`),
  CONSTRAINT `users_fk_1` FOREIGN KEY (`userid`) REFERENCES `login` (`UserID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
